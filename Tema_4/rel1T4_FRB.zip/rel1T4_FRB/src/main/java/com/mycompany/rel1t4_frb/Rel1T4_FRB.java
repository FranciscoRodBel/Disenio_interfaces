/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.rel1t4_frb;

/**
 *
 * @author Francisco
 */
public class Rel1T4_FRB {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
