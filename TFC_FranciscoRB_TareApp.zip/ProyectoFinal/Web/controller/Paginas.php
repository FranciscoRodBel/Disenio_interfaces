<?php

    class Paginas {

        public function inicio() {
            
            include './view/inicio.php';
        }
    }