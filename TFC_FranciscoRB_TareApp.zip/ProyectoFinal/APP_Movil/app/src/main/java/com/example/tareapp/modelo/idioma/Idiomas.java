/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.tareapp.modelo.idioma;

import java.util.ArrayList;

/**
 * Clase para el modelo de los idiomas, es una rray con todos los idiomas
 *
 * @author Francisco
 */
public class Idiomas {

    private ArrayList<Idioma> idioma;
    
    public ArrayList<Idioma> getIdioma() {
        return idioma;
    }

    public void setIdioma(ArrayList<Idioma> idioma) {
        this.idioma = idioma;
    }
}
