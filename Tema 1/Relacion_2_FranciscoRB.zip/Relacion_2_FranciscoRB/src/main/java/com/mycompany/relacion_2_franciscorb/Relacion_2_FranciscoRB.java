/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.relacion_2_franciscorb;

/**
 *
 * @author Francisco
 */
public class Relacion_2_FranciscoRB {

    public static void main(String[] args) {

    }
}
