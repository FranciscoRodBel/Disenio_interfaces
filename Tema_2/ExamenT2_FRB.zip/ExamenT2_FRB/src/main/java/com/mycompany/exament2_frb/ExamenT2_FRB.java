/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exament2_frb;

/**
 *
 * @author Francisco
 */
public class ExamenT2_FRB {

    public static void main(String[] args) {
        
    }
}
