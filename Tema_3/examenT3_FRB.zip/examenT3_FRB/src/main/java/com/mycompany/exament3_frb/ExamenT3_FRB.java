/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exament3_frb;

/**
 *
 * @author Francisco
 */
public class ExamenT3_FRB {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
